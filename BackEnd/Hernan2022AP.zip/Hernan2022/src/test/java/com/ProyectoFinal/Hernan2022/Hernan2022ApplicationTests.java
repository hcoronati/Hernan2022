package com.ProyectoFinal.Hernan2022;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hernan2022ApplicationTests {

	@Test
	void contextLoads() {
	}

}
